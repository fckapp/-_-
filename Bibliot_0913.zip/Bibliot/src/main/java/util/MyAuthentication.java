package util;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MyAuthentication extends Authenticator{
	
	PasswordAuthentication pa;
	
	public MyAuthentication() {
		String id = "hamjang99";
		String pw = "Hkawjdtlr1~";
		
		pa = new PasswordAuthentication(id, pw);
	}

	@Override
	protected PasswordAuthentication getPasswordAuthentication() {
		// TODO Auto-generated method stub
		return pa;
	}
	
}
